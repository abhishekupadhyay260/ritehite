package com.ritehite.crus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrusApplicationTests {

	@Test
	void contextLoads() {
	}

}
