package com.example.RiteHite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RiteHiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
